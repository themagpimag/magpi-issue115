# magpi_115
Code for the piece 'Get Started with Electronics with Raspberry Pi' in issue 115 of Mag Pi Magazine
